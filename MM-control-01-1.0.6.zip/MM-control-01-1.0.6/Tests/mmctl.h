/*
 * mmctl.h
 *
 *  Created on: Nov 12, 2018
 *      Author: marek
 */

#ifndef MMCTL_H_
#define MMCTL_H_

extern int active_extruder;



#endif /* MMCTL_H_ */
