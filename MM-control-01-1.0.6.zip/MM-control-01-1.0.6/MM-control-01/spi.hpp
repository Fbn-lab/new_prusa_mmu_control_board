//spi.h - hardware SPI
#ifndef _SPI_HPP_
#define _SPI_HPP_

#include "inttypes.h"
#include "avr/io.h"
#include "config.h"


#define SPI_SPCR(rat, pha, pol, mst, dor) ((rat & 3) | (pha?(1<<CPHA):0) | (pol?(1<<CPOL):0) | (mst?(1<<MSTR):0) | (dor?(1<<DORD):0) | (1<<SPE))
#define SPI_SPSR(rat) ((rat & 4)?(1<<SPI2X):0)

#define DD_SCK  1
#define DD_MOSI 2
#define DD_MISO 3

 void spi_init();

 void spi_setup(uint8_t spcr, uint8_t spsr);

 uint8_t spi_txrx(uint8_t tx);


#endif //SPI_H
